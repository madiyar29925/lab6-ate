/*
 * GccApplication1.c
 *
 * Created: 15.04.2021 22:27:35
 * Author : kipch
 */ 

#include <avr/io.h>


int main(void)
{
    /* Replace with your application code */
    while (1) 
    {
    }
}

